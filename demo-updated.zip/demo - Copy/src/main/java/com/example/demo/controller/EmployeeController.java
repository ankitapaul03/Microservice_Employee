package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Employee;
import com.example.demo.service.EmployeeService;
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api")
@RestController
public class EmployeeController {

	
	@Autowired
	EmployeeService employeeService;
	
	@GetMapping("/health")
	String health()
	{
		return "healthy";
	}
	
	@GetMapping("/employees")
	List<Employee> fetchEmployee()
	{
		return employeeService.fetchEmployee();
	}
	@PostMapping("/employees")
	Employee addEmployee(@RequestBody Employee employee)
	{
		return employeeService.addEmployee(employee);
	}
	
	@GetMapping("/employees/{id}")
	public Employee fetchEmployeeById(@PathVariable("id") Long empId) {
		return employeeService.fetchEmployeeById(empId);
	}

	@DeleteMapping("/employees/{id}")
	public String deleteEmployee(@PathVariable("id") Long empId) {
		return employeeService.deleteEmployee(empId);
	}

	@PutMapping("/employees/{id}")
	public Employee editEmployee(@PathVariable("id") Long empId, @RequestBody Employee employee) {
		return employeeService.editEmployee(empId, employee);
	}
	
	
}
