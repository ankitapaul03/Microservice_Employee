package com.example.demo.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepository employeeRepository;
	@Override
	public List<Employee> fetchEmployee() {
		
		return employeeRepository.findAll();
	}
	@Override
	public Employee addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return employeeRepository.save(employee);
	}
	@Override
	public Employee fetchEmployeeById(Long empId) {
		// TODO Auto-generated method stub
		return employeeRepository.findById(empId).get();
	}
	@Override
	public String deleteEmployee(Long empId) {
		// TODO Auto-generated method stub
		Employee e=employeeRepository.findById(empId).get();
		employeeRepository.delete(e);
		return "Employee record deleted";
	}
	@Override
	public Employee editEmployee(Long empId, Employee employee) {
		// TODO Auto-generated method stub
		Employee e = employeeRepository.findById(empId).get();
		if (Objects.nonNull(employee.getEmpName()) && !"".equals(employee.getEmpName())) {
			e.setEmpName(employee.getEmpName());
		}
		
		if (Objects.nonNull(employee.getEmpLoc()) && !"".equals(employee.getEmpLoc())) {
			e.setEmpLoc(employee.getEmpLoc());
		}
		if (Objects.nonNull(employee.getEmpSalary()) && !"".equals(employee.getEmpSalary())) {
			e.setEmpSalary(employee.getEmpSalary());
		}

		return employeeRepository.save(e);
	}

}
