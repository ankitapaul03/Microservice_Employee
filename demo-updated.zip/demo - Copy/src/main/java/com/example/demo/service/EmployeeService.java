package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Employee;

public interface EmployeeService {

	List<Employee> fetchEmployee();

	Employee addEmployee(Employee employee);

	Employee fetchEmployeeById(Long empId);

	String deleteEmployee(Long empId);

	Employee editEmployee(Long empId, Employee employee);

}
